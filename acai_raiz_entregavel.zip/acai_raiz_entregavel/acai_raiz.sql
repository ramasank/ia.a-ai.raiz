
CREATE DATABASE IF NOT EXISTS acai_raiz;
USE acai_raiz;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100),
    senha VARCHAR(100)
);

INSERT INTO usuarios (nome, email, senha) VALUES ('Admin', 'admin@acai.com', '1234');

CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    descricao TEXT,
    preco DECIMAL(10,2),
    imagem VARCHAR(255),
    categoria VARCHAR(50),
    destaque BOOLEAN DEFAULT 0
);

INSERT INTO produtos (nome, descricao, preco, imagem, categoria, destaque) VALUES
('Açaí Tradicional 300ml', 'Açaí puro com granola.', 10.90, 'trad_300.jpg', 'acai_tradicional', 1),
('Açaí com Morango', 'Açaí com morango fresco.', 12.90, 'morango.jpg', 'acai_com_frutas', 1),
('Banana com Açaí', 'Banana e leite condensado.', 13.90, 'banana.jpg', 'acai_com_frutas', 0),
('Suco Natural', 'Suco natural tropical.', 6.50, 'suco.jpg', 'bebidas', 1);
