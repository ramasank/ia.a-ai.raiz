<?php
session_start();

if (!isset($_SESSION['carrinho']) || empty($_SESSION['carrinho'])) {
    header("Location: carrinho.php");
    exit();
}

// Se o formulário for enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['dados_cliente'] = [
        'nome' => $_POST['nome'] ?? '',
        'telefone' => $_POST['telefone'] ?? '',
        'endereco' => $_POST['endereco'] ?? '',
        'cpf' => $_POST['cpf'] ?? ''
    ];

    // Aqui você pode simular a geração de um QRCode ou link de PIX real
    header("Location: pagamento.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Finalizar Pedido - Açaí Raiz</title>
    <link rel="stylesheet" href="style/main.css">
</head>
<body>
    <header>
        <img src="assets/produtos/logo1.png" alt="Logo Açaí Raiz" class="logo">
        <h1>Finalizar Pedido</h1>
        <a href="carrinho.php">← Voltar ao carrinho</a>
    </header>

    <main>
        <h2>Resumo do Pedido</h2>
        <div class="produtos">
            <?php foreach ($_SESSION['carrinho'] as $index => $pedido): ?>
                <div class="produto">
                    <h3>Pedido <?= $index + 1 ?></h3>
                    <p><strong>Tamanho:</strong> <?= htmlspecialchars($pedido['tamanho']) ?> ml</p>
                    <p><strong>Complementos:</strong> 
                        <?= $pedido['complementos'] ? implode(", ", array_map('htmlspecialchars', $pedido['complementos'])) : 'Nenhum' ?>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>

        <h2>Dados do Cliente</h2>
        <form method="POST" style="max-width: 500px; margin: auto;">
            <label>Nome completo:</label><br>
            <input type="text" name="nome" required><br><br>

            <label>Telefone:</label><br>
            <input type="text" name="telefone" required><br><br>

            <label>Endereço:</label><br>
            <input type="text" name="endereco" required><br><br>

            <label>CPF:</label><br>
            <input type="text" name="cpf" required><br><br>

            <button type="submit" class="botao">Gerar pagamento</button>
        </form>
    </main>
</body>
</html>
