<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Histórico de Compras</title>
    <link rel="stylesheet" href="style/main.css">
</head>
<body>
    <h1>Histórico de Compras</h1>
    <p>Em breve, aqui estarão listadas suas compras anteriores.</p>
</body>
</html>
