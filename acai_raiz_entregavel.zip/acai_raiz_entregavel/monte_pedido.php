<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Monte seu pedido - Açaí Raiz</title>
    <link rel="stylesheet" href="style/main.css">
</head>
<body>
    <header>
        <img src="assets/produtos/logo1.png" alt="Logo Açaí Raiz" class="logo">
        <h1>Escolha o tamanho do seu Açaí</h1>
        <a href="index.php">← Voltar ao início</a>
    </header>

    <main>
        <div class="produtos">
            <!-- Açaí 150ml -->
            <div class="produto">
                <img src="assets/produtos/acai150.jpg.png" alt="Açaí 150ml">
                <h3>Açaí 150ml</h3>
                <p>Ideal para um lanche leve.</p>
                <span>R$ 7,00</span>
                <a href="categorias/complementos.php?tamanho=150" class="botao">Quero esse</a>
            </div>

            <!-- Açaí 300ml -->
            <div class="produto">
                <img src="assets/produtos/acai300.jpg.png" alt="Açaí 300ml">
                <h3>Açaí 300ml</h3>
                <p>Perfeito para matar a vontade.</p>
                <span>R$ 10,00</span>
                <a href="categorias/complementos.php?tamanho=300" class="botao">Quero esse</a>
            </div>

            <!-- Açaí 500ml -->
            <div class="produto">
                <img src="assets/produtos/acai500.jpg.png" alt="Açaí 500ml">
                <h3>Açaí 500ml</h3>
                <p>Para quem ama açaí de verdade.</p>
                <span>R$ 14,00</span>
                <a href="categorias/complementos.php?tamanho=500" class="botao">Quero esse</a>
            </div>
        </div>
    </main>
</body>
</html>
