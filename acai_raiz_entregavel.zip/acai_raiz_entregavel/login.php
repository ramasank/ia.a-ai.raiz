<?php
session_start();
include 'includes/conexao.php';

$msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM usuarios WHERE email = '$email' AND senha = '$senha'";
    $res = $conn->query($sql);

    if ($res && $res->num_rows > 0) {
        $_SESSION['logado'] = true;
        header("Location: index.php");
        exit();
    } else {
        $msg = "Login inválido!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style/login.css">
</head>
<body>
    <form method="POST">
        <img src="assets/produtos/logo1.png" alt="Logo Açaí Raiz" class="logo-login">
        
        <h2>Login</h2>

        <input type="email" name="email" placeholder="Digite seu e-mail" required><br>
        <input type="password" name="senha" placeholder="Digite sua senha" required><br>
        <button type="submit">Entrar</button>

        <?php if (!empty($msg)): ?>
            <p style="color:red;"><?= $msg ?></p>
        <?php endif; ?>
    </form>
</body>
</html>
