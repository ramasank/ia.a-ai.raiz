<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['dados_cliente'] = [
        'nome' => $_POST['nome'],
        'telefone' => $_POST['telefone'],
        'endereco' => $_POST['endereco'],
        'cpf' => $_POST['cpf']
    ];
    header("Location: carrinho.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Endereço</title>
    <link rel="stylesheet" href="style/main.css">
</head>
<body>
    <h1>Cadastrar Endereço</h1>
    <form method="POST">
        <label>Nome:</label><br>
        <input type="text" name="nome" required><br><br>

        <label>Telefone:</label><br>
        <input type="text" name="telefone" required><br><br>

        <label>Endereço:</label><br>
        <input type="text" name="endereco" required><br><br>

        <label>CPF:</label><br>
        <input type="text" name="cpf" required><br><br>

        <button type="submit">Salvar</button>
    </form>
</body>
</html>
