<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}
include '../includes/conexao.php';

// Buscar categorias
$cats = $conn->query("SELECT * FROM categorias");

// Pegar ID do produto
$id = intval($_GET['id']);
$produto = $conn->query("SELECT * FROM produtos WHERE id = $id")->fetch_assoc();

// Atualizar produto
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];
    $imagem = $_POST['imagem'];
    $categoria_id = $_POST['categoria_id'];
    $destaque = isset($_POST['destaque']) ? 1 : 0;

    $sql = "UPDATE produtos SET 
                nome='$nome', descricao='$descricao', preco='$preco', 
                imagem='$imagem', categoria_id='$categoria_id', destaque='$destaque'
            WHERE id = $id";
    $conn->query($sql);

    header("Location: produtos.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Produto</title>
    <link rel="stylesheet" href="../style/admin.css">
</head>
<body>
<header>
    <h1>Editar Produto</h1>
    <a href="produtos.php">Voltar</a>
</header>
<main>
<form method="POST">
    <input type="text" name="nome" value="<?= $produto['nome'] ?>" required><br>
    <textarea name="descricao" required><?= $produto['descricao'] ?></textarea><br>
    <input type="number" step="0.01" name="preco" value="<?= $produto['preco'] ?>" required><br>
    <input type="text" name="imagem" value="<?= $produto['imagem'] ?>"><br>
    <select name="categoria_id" required>
        <?php while($c = $cats->fetch_assoc()): ?>
            <option value="<?= $c['id'] ?>" <?= $c['id']==$produto['categoria_id']?'selected':'' ?>>
                <?= $c['nome'] ?>
            </option>
        <?php endwhile; ?>
    </select><br>
    <label><input type="checkbox" name="destaque" <?= $produto['destaque'] ? 'checked' : '' ?>> Destaque</label><br>
    <button type="submit">Atualizar</button>
</form>
</main>
</body>
</html>
