<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}
include '../includes/conexao.php';

// Adicionar categoria
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nova_categoria'])) {
    $nome = $_POST['nova_categoria'];
    $conn->query("INSERT INTO categorias (nome) VALUES ('$nome')");
}

// Excluir categoria
if (isset($_GET['excluir'])) {
    $id = intval($_GET['excluir']);
    $conn->query("DELETE FROM categorias WHERE id = $id");
}

// Buscar categorias
$cats = $conn->query("SELECT * FROM categorias");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Categorias</title>
    <link rel="stylesheet" href="../style/admin.css">
</head>
<body>
<header>
    <h1>Categorias</h1>
    <a href="admin.php">Voltar</a>
</header>
<main>
<form method="POST">
    <input type="text" name="nova_categoria" placeholder="Nova categoria" required>
    <button type="submit">Adicionar</button>
</form>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Ações</th>
    </tr>
    <?php while($c = $cats->fetch_assoc()): ?>
    <tr>
        <td><?= $c['id'] ?></td>
        <td><?= $c['nome'] ?></td>
        <td>
            <a href="categorias.php?excluir=<?= $c['id'] ?>" onclick="return confirm('Excluir categoria?')">Excluir</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
</main>
</body>
</html>
