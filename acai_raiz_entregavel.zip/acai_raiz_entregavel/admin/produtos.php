<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}
include '../includes/conexao.php';

// Buscar produtos e categorias
$sql = "SELECT p.*, c.nome AS categoria FROM produtos p 
        LEFT JOIN categorias c ON p.categoria_id = c.id";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Produtos - Açaí Raiz</title>
    <link rel="stylesheet" href="../style/admin.css">
</head>
<body>
<header>
    <h1>Gerenciar Produtos</h1>
    <a href="novo_produto.php">+ Novo Produto</a> |
    <a href="admin.php">Voltar</a>
</header>
<main>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Preço</th>
        <th>Categoria</th>
        <th>Destaque</th>
        <th>Ações</th>
    </tr>
    <?php while($p = $res->fetch_assoc()): ?>
    <tr>
        <td><?= $p['id'] ?></td>
        <td><?= $p['nome'] ?></td>
        <td>R$ <?= number_format($p['preco'], 2, ',', '.') ?></td>
        <td><?= $p['categoria'] ?></td>
        <td><?= $p['destaque'] ? 'Sim' : 'Não' ?></td>
        <td>
            <a href="editar_produto.php?id=<?= $p['id'] ?>">Editar</a> |
            <a href="produtos.php?excluir=<?= $p['id'] ?>" onclick="return confirm('Excluir produto?')">Excluir</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
</main>
</body>
</html>
<?php
// Excluir produto
if (isset($_GET['excluir'])) {
    $id = intval($_GET['excluir']);
    $conn->query("DELETE FROM produtos WHERE id = $id");
    header("Location: produtos.php");
}
?>
