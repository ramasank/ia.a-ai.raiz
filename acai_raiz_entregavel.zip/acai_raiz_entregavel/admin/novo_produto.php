<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}
include '../includes/conexao.php';

// Buscar categorias
$cats = $conn->query("SELECT * FROM categorias");

// Inserir produto
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];
    $imagem = $_POST['imagem'];
    $categoria_id = $_POST['categoria_id'];
    $destaque = isset($_POST['destaque']) ? 1 : 0;

    $sql = "INSERT INTO produtos (nome, descricao, preco, imagem, categoria_id, destaque)
            VALUES ('$nome', '$descricao', '$preco', '$imagem', '$categoria_id', '$destaque')";
    $conn->query($sql);

    header("Location: produtos.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Novo Produto</title>
    <link rel="stylesheet" href="../style/admin.css">
</head>
<body>
<header>
    <h1>Novo Produto</h1>
    <a href="produtos.php">Voltar</a>
</header>
<main>
<form method="POST">
    <input type="text" name="nome" placeholder="Nome do produto" required><br>
    <textarea name="descricao" placeholder="Descrição" required></textarea><br>
    <input type="number" step="0.01" name="preco" placeholder="Preço" required><br>
    <input type="text" name="imagem" placeholder="Nome do arquivo da imagem"><br>
    <select name="categoria_id" required>
        <?php while($c = $cats->fetch_assoc()): ?>
            <option value="<?= $c['id'] ?>"><?= $c['nome'] ?></option>
        <?php endwhile; ?>
    </select><br>
    <label><input type="checkbox" name="destaque"> Destaque</label><br>
    <button type="submit">Salvar</button>
</form>
</main>
</body>
</html>
