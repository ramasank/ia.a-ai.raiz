<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}
include '../includes/conexao.php';

// Atualizar status do pedido
if (isset($_GET['concluir'])) {
    $id = intval($_GET['concluir']);
    $conn->query("UPDATE pedidos SET status='Concluído' WHERE id = $id");
}

// Buscar pedidos
$sql = "SELECT * FROM pedidos ORDER BY data_pedido DESC";
$pedidos = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Pedidos</title>
    <link rel="stylesheet" href="../style/admin.css">
</head>
<body>
<header>
    <h1>Pedidos</h1>
    <a href="admin.php">Voltar</a>
</header>
<main>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Total</th>
        <th>Status</th>
        <th>Data</th>
        <th>Ações</th>
    </tr>
    <?php while($p = $pedidos->fetch_assoc()): ?>
    <tr>
        <td><?= $p['id'] ?></td>
        <td>R$ <?= number_format($p['total'], 2, ',', '.') ?></td>
        <td><?= $p['status'] ?></td>
        <td><?= $p['data_pedido'] ?></td>
        <td>
            <?php if ($p['status'] !== 'Concluído'): ?>
                <a href="pedidos.php?concluir=<?= $p['id'] ?>">Marcar como Concluído</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
</main>
</body>
</html>
