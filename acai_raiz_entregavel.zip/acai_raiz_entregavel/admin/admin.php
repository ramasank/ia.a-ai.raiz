<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="../style/admin.css">
    <meta charset="UTF-8">
    <title>Painel Administrativo - Açaí Raiz</title>
</head>
<body>
<header>
    <h1>Painel Administrativo</h1>
    <nav>
        <a href="produtos.php">Gerenciar Produtos</a> |
        <a href="categorias.php">Gerenciar Categorias</a> |
        <a href="pedidos.php">Visualizar Pedidos</a> |
        <a href="../index.php">Voltar ao site</a>
    </nav>
</header>
<main>
    <p>Bem-vindo ao painel! Escolha uma opção acima para gerenciar o sistema.</p>
</main>
</body>
</html>
