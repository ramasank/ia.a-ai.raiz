<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Açaís - Açaí Raiz</title>
    <link rel="stylesheet" href="../style/main.css">
</head>
<body>
    <header>
        <img src="../assets/produtos/logo.jpg" alt="Logo Açaí Raiz" class="logo">
        <h1>Categoria: Açaís</h1>
        <a href="../index.php">← Voltar ao início</a>
    </header>

    <main>
        <div class="produtos">
            <div class="produto">
                <img src="../assets/produtos/acai300.jpg.png" alt="Açaí 300ml">
                <h3>Açaí 300ml</h3>
                <p>Açaí tradicional, ideal para refrescar o dia.</p>
                <span>R$ 10,00</span>
            </div>

            <div class="produto">
                <img src="../assets/produtos/acaimorango.jpg.png" alt="Açaí com Morango">
                <h3>Açaí com Morango</h3>
                <p>Açaí gelado com morangos frescos.</p>
                <span>R$ 12,00</span>
            </div>

            <div class="produto">
                <img src="../assets/produtos/acai_granola.jpg.png" alt="Açaí com Granola">
                <h3>Açaí com Granola</h3>
                <p>Delicioso açaí coberto com granola crocante.</p>
                <span>R$ 13,50</span>
            </div>
        </div>
    </main>
</body>
</html>
