<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sorvetes - Açaí Raiz</title>
    <link rel="stylesheet" href="../style/main.css">
</head>
<body>
    <header>
        <img src="../assets/produtos/logo.jpg" alt="Logo Açaí Raiz" class="logo">
        <h1>Categoria: Sorvetes</h1>
        <a href="../index.php">← Voltar ao início</a>
    </header>

    <main>
        <div class="produtos">
            <div class="produto">
                <img src="../assets/produtos/sorvete_creme.jpg.png" alt="Sorvete de Creme">
                <h3>Sorvete de Creme</h3>
                <p>Clássico e saboroso, combina com tudo.</p>
                <span>R$ 6,00</span>
            </div>

            <div class="produto">
                <img src="../assets/produtos/sorvete_chocolate.jpg.png" alt="Sorvete de Chocolate">
                <h3>Sorvete de Chocolate</h3>
                <p>Chocolate intenso para os chocólatras.</p>
                <span>R$ 7,00</span>
            </div>

            <div class="produto">
                <img src="../assets/produtos/sorvete_morango.jpg.png" alt="Sorvete de Morango">
                <h3>Sorvete de Morango</h3>
                <p>Feito com morangos frescos e naturais.</p>
                <span>R$ 6,50</span>
            </div>
        </div>
    </main>
</body>
</html>
