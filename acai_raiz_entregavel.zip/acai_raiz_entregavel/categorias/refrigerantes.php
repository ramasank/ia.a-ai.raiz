<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Refrigerantes - Açaí Raiz</title>
    <link rel="stylesheet" href="../style/main.css">
</head>
<body>
    <header>
        <img src="../assets/produtos/logo.jpg" alt="Logo Açaí Raiz" class="logo">
        <h1>Categoria: Refrigerantes</h1>
        <a href="../index.php">← Voltar ao início</a>
    </header>

    <main>
        <div class="produtos">
            <div class="produto">
                <img src="../assets/produtos/guarana.jpg.png" alt="Guaraná">
                <h3>Guaraná</h3>
                <p>Clássico e gelado, ideal para acompanhar o açaí.</p>
                <span>R$ 6,00</span>
            </div>

            <div class="produto">
                <img src="../assets/produtos/coca.jpg.png" alt="Coca-Cola">
                <h3>Coca-Cola</h3>
                <p>Refrigerante tradicional 350ml.</p>
                <span>R$ 6,50</span>
            </div>

            <div class="produto">
                <img src="../assets/produtos/sprit.jpg.png" alt="Sprite">
                <h3>Sprite</h3>
                <p>Refrigerante leve de limão, bem gelado.</p>
                <span>R$ 6,00</span>
            </div>
        </div>
    </main>
</body>
</html>
