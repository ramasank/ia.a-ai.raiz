<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Complementos - Açaí Raiz</title>
    <link rel="stylesheet" href="../style/main.css">
</head>
<body>
    <header>
        <img src="../assets/produtos/logo.jpg" alt="Logo Açaí Raiz" class="logo">
        <h1>Categoria: Complementos</h1>
        <a href="../index.php">← Voltar ao início</a>
    </header>

    <main>
        <div class="produtos">
            <div class="produto">
                <img src="../assets/produtos/granola.jpg.png" alt="Granola">
                <h3>Granola</h3>
                <p>Crocante, perfeita para açaí e iogurtes.</p>
                <span>R$ 3,00</span>
            </div>

            <div class="produto">
                <img src="../assets/produtos/banana.jpg.png" alt="Banana em rodelas">
                <h3>Banana</h3>
                <p>Banana fatiada para adicionar ao seu açaí.</p>
                <span>R$ 2,00</span>
            </div>

            <div class="produto">
                <img src="../assets/produtos/leite_condesado.jpg.png" alt="Leite Condensado">
                <h3>Leite Condensado</h3>
                <p>Doce e cremoso, ideal como cobertura.</p>
                <span>R$ 2,50</span>
            </div>
        </div>
    </main>
</body>
</html>
