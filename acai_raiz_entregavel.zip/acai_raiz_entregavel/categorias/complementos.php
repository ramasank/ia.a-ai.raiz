<?php
$tamanho = isset($_GET['tamanho']) ? $_GET['tamanho'] : 'Não especificado';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Monte seu pedido - Complementos</title>
    <link rel="stylesheet" href="../style/main.css">
</head>
<body>
    <header>
        <img src="../assets/produtos/logo.jpg" alt="Logo Açaí Raiz" class="logo">
        <h1>Escolha seus complementos</h1>
        <p>Tamanho selecionado: <strong><?php echo htmlspecialchars($tamanho); ?> ml</strong></p>
        <a href="../index.php">&#8592; Voltar ao início</a>
    </header>

    <main>
        <form action="../carrinho.php" method="POST">
            <input type="hidden" name="tamanho" value="<?php echo htmlspecialchars($tamanho); ?>">
            <div class="produtos">
                <div class="produto">
                    <img src="../assets/produtos/granola.jpg.png" alt="Granola">
                    <h3>Granola</h3>
                    <p>Crocante, perfeita para açaí e iogurtes.</p>
                    <span>R$ 3,00</span><br>
                    <label><input type="checkbox" name="complementos[]" value="Granola"> Adicionar</label>
                </div>

                <div class="produto">
                    <img src="../assets/produtos/banana.jpg.png" alt="Banana">
                    <h3>Banana</h3>
                    <p>Banana fatiada para adicionar ao seu açaí.</p>
                    <span>R$ 2,00</span><br>
                    <label><input type="checkbox" name="complementos[]" value="Banana"> Adicionar</label>
                </div>

                <div class="produto">
                    <img src="../assets/produtos/leite_condesado.jpg.png" alt="Leite Condensado">
                    <h3>Leite Condensado</h3>
                    <p>Doce e cremoso, ideal como cobertura.</p>
                    <span>R$ 2,50</span><br>
                    <label><input type="checkbox" name="complementos[]" value="Leite Condensado"> Adicionar</label>
                </div>
            </div>
            <div style="text-align:center; margin-top: 20px;">
                <button type="submit" class="botao">Continuar Pedido</button>
            </div>
        </form>
    </main>
</body>
</html>