<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}

include '../includes/conexao.php';

// Pegar ID da categoria pela URL (?id=1)
$categoria_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Verificar se categoria existe
$cat_res = $conn->query("SELECT nome FROM categorias WHERE id = $categoria_id");
if ($cat_res->num_rows == 0) {
    die("Categoria não encontrada!");
}
$categoria = $cat_res->fetch_assoc()['nome'];

// Pegar produtos da categoria
$prod_res = $conn->query("SELECT * FROM produtos WHERE categoria_id = $categoria_id");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title><?= $categoria ?> - Açaí Raiz</title>
    <link rel="stylesheet" href="../style/main.css">
</head>
<body>
    <header>
        <img src="../assets/produtos/logo.jpg" alt="Logo Açaí Raiz" class="logo">
        <h1>Categoria: <?= $categoria ?></h1>
        <a href="../index.php">← Voltar ao início</a>
    </header>

    <main>
        <div class="produtos">
            <?php if ($prod_res->num_rows > 0): ?>
                <?php while ($row = $prod_res->fetch_assoc()): ?>
                    <div class="produto">
                        <img src="../assets/produtos/<?= $row['imagem'] ?>" alt="<?= $row['nome'] ?>">
                        <h3><?= $row['nome'] ?></h3>
                        <p><?= $row['descricao'] ?></p>
                        <span>R$ <?= number_format($row['preco'], 2, ',', '.') ?></span>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>Nenhum produto cadastrado nesta categoria.</p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
