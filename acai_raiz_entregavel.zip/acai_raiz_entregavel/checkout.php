<?php
session_start();
include 'includes/conexao.php';

// Se o carrinho estiver vazio, redireciona para o index
if (!isset($_SESSION['carrinho']) || empty($_SESSION['carrinho'])) {
    header("Location: index.php");
    exit();
}

$msg = "";

// Quando o usuário confirma o pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Calcular total
    $total = 0;
    foreach ($_SESSION['carrinho'] as $item) {
        $total += $item['preco'] * $item['quantidade'];
    }

    // Criar pedido
    $conn->query("INSERT INTO pedidos (usuario_id, total) VALUES (NULL, $total)");
    $pedido_id = $conn->insert_id;

    // Inserir itens do pedido
    foreach ($_SESSION['carrinho'] as $produto_id => $item) {
        $quantidade = $item['quantidade'];
        $preco_unit = $item['preco'];
        $conn->query("INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario)
                      VALUES ($pedido_id, $produto_id, $quantidade, $preco_unit)");
    }

    // Limpar carrinho
    $_SESSION['carrinho'] = [];

    $msg = "Pedido realizado com sucesso! Apresente o QR Code para pagamento.";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Finalizar Pedido - Açaí Raiz</title>
    <link rel="stylesheet" href="style/main.css">
</head>
<body>
<header>
    <h1>Finalizar Pedido</h1>
    <a href="carrinho.php">← Voltar ao Carrinho</a>
</header>

<main>
    <?php if ($msg): ?>
        <h2><?= $msg ?></h2>
        <img src="https://api.qrserver.com/v1/create-qr-code/?data=Pagamento%20Açaí%20Raiz&size=200x200" alt="QR Code">
        <p>Mostre este QR Code no caixa para confirmar o pagamento.</p>
        <a href="index.php">Voltar à página inicial</a>
    <?php else: ?>
        <h2>Resumo do Pedido</h2>
        <ul>
            <?php foreach ($_SESSION['carrinho'] as $item): ?>
                <li><?= $item['quantidade'] ?>x <?= $item['nome'] ?> - R$ <?= number_format($item['preco'] * $item['quantidade'], 2, ',', '.') ?></li>
            <?php endforeach; ?>
        </ul>
        <form method="POST">
            <button type="submit">Confirmar Pedido</button>
        </form>
    <?php endif; ?>
</main>
</body>
</html>

