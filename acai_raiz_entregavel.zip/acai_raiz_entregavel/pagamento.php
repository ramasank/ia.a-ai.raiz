
<?php
session_start();
unset($_SESSION['carrinho']);

// Verifica se os dados estão preenchidos
if (!isset($_SESSION['carrinho']) || !isset($_SESSION['dados_cliente'])) {
    header("Location: index.php");
    exit();
}

$cliente = $_SESSION['dados_cliente'];
$pedidos = $_SESSION['carrinho'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Pagamento - Açaí Raiz</title>
    <link rel="stylesheet" href="style/main.css">
</head>
<body>
    <header>
        <img src="assets/produtos/logo1.png" alt="Logo Açaí Raiz" class="logo">
        <h1>Pagamento via Pix</h1>
    </header>

    <main>
        <section>
            <h2>Resumo do Pedido</h2>
            <?php foreach ($pedidos as $index => $pedido): ?>
                <div class="produto">
                    <h3>Pedido <?= $index + 1 ?></h3>
                    <p><strong>Tamanho:</strong> <?= htmlspecialchars($pedido['tamanho']) ?> ml</p>
                    <p><strong>Complementos:</strong> 
                        <?= $pedido['complementos'] ? implode(", ", array_map('htmlspecialchars', $pedido['complementos'])) : 'Nenhum' ?>
                    </p>
                </div>
            <?php endforeach; ?>
        </section>

        <section>
            <h2>Dados do Cliente</h2>
            <p><strong>Nome:</strong> <?= htmlspecialchars($cliente['nome']) ?></p>
            <p><strong>Telefone:</strong> <?= htmlspecialchars($cliente['telefone']) ?></p>
            <p><strong>Endereço:</strong> <?= htmlspecialchars($cliente['endereco']) ?></p>
            <p><strong>CPF:</strong> <?= htmlspecialchars($cliente['cpf']) ?></p>
        </section>

        <section>
            <h2>Chave Pix para pagamento</h2>
            <p>Escaneie o QR Code abaixo com seu app bancário ou copie a chave Pix:</p>
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=pix@acairaiz.com" alt="QR Code Pix">
            <p><strong>Chave Pix:</strong> <code>pix@acairaiz.com</code></p>
        </section>

        <section>
            <h2>Confirmação</h2>
            <p>Após realizar o pagamento, clique abaixo para confirmar com um atendente:</p>
            <a href="https://wa.me/5599999999999?text=Olá%2C+acabei+de+realizar+um+pedido+no+Açaí+Raiz%21" target="_blank" class="botao">
                Falar com Atendente no WhatsApp
            </a>
        </section>
    </main>
</body>
</html>
