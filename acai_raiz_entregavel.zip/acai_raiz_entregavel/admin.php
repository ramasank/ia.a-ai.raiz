<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: login.php");
    exit();
}
echo "<h1>Painel Administrativo</h1><a href='logout.php'>Sair</a>";
?>