<?php
session_start();
include 'includes/conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $endereco = $_POST['endereco'];
    $telefone = $_POST['telefone'];
    $cpf = $_POST['cpf'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO usuarios (email, endereco, telefone, cpf, senha) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $email, $endereco, $telefone, $cpf, $senha);

    if ($stmt->execute()) {
        $_SESSION['logado'] = true;
        $_SESSION['email'] = $email;
        header("Location: index.php");
        exit();
    } else {
        $erro = "Erro ao cadastrar usuário.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - Açaí Raiz</title>
    <link rel="stylesheet" href="style/login.css">
</head>
<body>
    <div class="login-container">
        <img src="assets/produtos/logo1.png" alt="Logo Açaí Raiz" class="logo">
        <h2>Cadastro de Cliente</h2>

        <?php if (isset($erro)) echo "<p style='color:red;'>$erro</p>"; ?>

        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="endereco" placeholder="Endereço" required>
            <input type="text" name="telefone" placeholder="Número de Telefone" required>
            <input type="text" name="cpf" placeholder="CPF" required>
            <input type="password" name="senha" placeholder="Crie uma Senha" required>
            <button type="submit">Cadastrar</button>
        </form>

        <p>Já tem uma conta? <a href="login.php">Faça login</a></p>
    </div>
</body>
</html>
