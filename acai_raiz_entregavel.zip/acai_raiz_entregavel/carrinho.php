<?php
session_start();

// Inicializar o carrinho se não existir
if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

// Verifica se recebeu dados via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tamanho = $_POST['tamanho'] ?? '';
    $complementos = $_POST['complementos'] ?? [];

    // Adiciona ao carrinho
    $_SESSION['carrinho'][] = [
        'tamanho' => $tamanho,
        'complementos' => $complementos
    ];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Carrinho - Açaí Raiz</title>
    <link rel="stylesheet" href="style/main.css">
</head>
<body>
    <header>
        <img src="assets/produtos/logo1.png" alt="Logo Açaí Raiz" class="logo">
        <h1>Resumo do Pedido</h1>
        <a href="index.php">← Voltar ao início</a>
    </header>

    <main>
        <?php if (empty($_SESSION['carrinho'])): ?>
            <p>Seu carrinho está vazio.</p>
        <?php else: ?>
            <div class="produtos">
                <?php foreach ($_SESSION['carrinho'] as $index => $pedido): ?>
                    <div class="produto">
                        <h3>Pedido <?= $index + 1 ?></h3>
                        <p><strong>Tamanho:</strong> <?= htmlspecialchars($pedido['tamanho']) ?> ml</p>
                        <p><strong>Complementos:</strong>
                            <?= $pedido['complementos'] ? implode(", ", array_map('htmlspecialchars', $pedido['complementos'])) : 'Nenhum' ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>

            <div style="text-align: center; margin-top: 20px;">
                <a href="monte_pedido.php" class="botao">➕ Montar outro pedido</a>
                <a href="finalizar.php" class="botao">✅ Finalizar Pedido</a>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>
