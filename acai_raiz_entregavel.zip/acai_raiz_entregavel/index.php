<?php 
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Açaí Raiz</title>
    <link rel="stylesheet" href="style/main.css">
</head>
<body>
    <header>
        
        
        <img src="assets/produtos/logo1.png" alt="Logo Açaí Raiz" class="logo">
        <h1>Bem-vindo ao Açaí Raiz</h1>
        
    </header>
    <nav class="menu-lateral">
    <ul>
        <li><a href="logout.php">Logout</a></li>
        <li><a href="historico.php">Histórico de Compras</a></li>
        <li><a href="carrinho.php">Carrinho</a></li>
        <li><a href="endereco.php">Cadastrar Endereço</a></li>
    </ul>
</nav>

    <main>
        <section class="destaques">
            <h2>Ofertas e Destaques</h2>
            <div class="produtos">
                <!-- Produto 1 -->
                <div class="produto">
                    <img src="assets/produtos/acai300.jpg.png" alt="Açaí Tradicional">
                    <h3>Açaí Tradicional</h3>
                    <p>Açaí cremoso puro com textura suave.</p>
                    <span>R$ 10,00</span>
                </div>

                <!-- Produto 2 -->
                <div class="produto">
                    <img src="assets/produtos/acaimorango.jpg.png" alt="Açaí com Morango">
                    <h3>Açaí com Morango</h3>
                    <p>Açaí gelado com morangos frescos picados.</p>
                    <span>R$ 12,00</span>
                </div>

                <!-- Produto 3 -->
                <div class="produto">
                    <img src="assets/produtos/guarana.jpg.png" alt="Guaraná">
                    <h3>Guaraná</h3>
                    <p>Bebida refrescante e energética.</p>
                    <span>R$ 6,00</span>
                </div>
            </div>
        </section>

        <section class="categorias">
            <h2>Categorias</h2>
            <ul>
                <li><a href="categorias/acais.php">Açaís</a></li>
                <li><a href="monte_pedido.php">Monte seu pedido</a></li>
                <li><a href="categorias/sorvetes.php">Sorvetes</a></li>
                <li><a href="categorias/refrigerantes.php">Refrigerantes</a></li>
            </ul>
        </section>
    </main>
</body>
</html>
